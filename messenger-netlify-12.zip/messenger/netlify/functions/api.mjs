// Серверная часть мессенджера (Netlify Function). Данные хранятся в Netlify Blobs.
import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';

const DAY = 864e5;
const pad = n => String(n).padStart(15, '0');
const day = ts => new Date(ts).toISOString().slice(0, 10);
// CORS: страница может лежать на другом адресе (например GitHub Pages). Авторизация идёт токеном в заголовке, не cookie, поэтому * безопасно.
const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'authorization, content-type',
  'access-control-allow-methods': 'GET, POST, OPTIONS',
  'access-control-max-age': '86400'
};
const J = (status, obj) => new Response(JSON.stringify(obj), {
  status,
  headers: Object.assign({ 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }, CORS)
});
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString('hex');
const sha = x => crypto.createHash('sha256').update(String(x)).digest('hex').slice(0, 32);
const OTP_TTL = 10 * 60e3;
const hashCode = (code, salt) => crypto.createHash('sha256').update(salt + ':' + code).digest('hex');
const normEmail = v => { const e = String(v || '').trim().toLowerCase(); return e.length <= 120 && /^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/.test(e) ? e : ''; };
const normPhone = v => {
  let p = String(v || '').replace(/[\s\-().]/g, '');
  if (/^8\d{10}$/.test(p)) p = '+7' + p.slice(1); else if (/^7\d{10}$/.test(p)) p = '+' + p;
  return /^\+\d{10,15}$/.test(p) ? p : '';
};
// Отправка кода. Провайдеры настраиваются переменными окружения Netlify (см. netlify.toml).
// Возвращает true (отправлено) или false (провайдер не настроен); при сбое бросает ошибку.
const sendCode = async (kind, to, code) => {
  const env = process.env;
  const text = 'Ваш код для входа в ARTEM: ' + code + '. Никому его не сообщайте. Действует 10 минут.';
  if (kind === 'email') {
    if (env.SMTP_USER && env.SMTP_PASS) { // Gmail (пароль приложения) или любой SMTP
      const nm = (await import('nodemailer')).default;
      const port = Number(env.SMTP_PORT) || 465;
      const tr = nm.createTransport({ host: env.SMTP_HOST || 'smtp.gmail.com', port, secure: port === 465, auth: { user: env.SMTP_USER, pass: env.SMTP_PASS } });
      await tr.sendMail({ from: env.MAIL_FROM || 'ARTEM <' + env.SMTP_USER + '>', to, subject: 'Код входа ARTEM: ' + code, text });
      return true;
    }
    if (env.RESEND_API_KEY) {
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { authorization: 'Bearer ' + env.RESEND_API_KEY, 'content-type': 'application/json' },
        body: JSON.stringify({ from: env.MAIL_FROM || 'ARTEM <onboarding@resend.dev>', to: [to], subject: 'Код входа ARTEM: ' + code, text })
      });
      if (!r.ok) throw new Error('resend ' + r.status + ' ' + (await r.text()).slice(0, 200));
      return true;
    }
    return false;
  }
  if (env.SMSRU_API_ID) { // sms.ru
    const r = await fetch('https://sms.ru/sms/send?api_id=' + encodeURIComponent(env.SMSRU_API_ID) + '&to=' + encodeURIComponent(to.slice(1)) + '&msg=' + encodeURIComponent(text) + '&json=1');
    const j = await r.json().catch(() => ({}));
    if (j.status !== 'OK') throw new Error('smsru ' + JSON.stringify(j).slice(0, 200));
    return true;
  }
  if (env.TWILIO_SID && env.TWILIO_TOKEN && (env.TWILIO_FROM || env.TWILIO_MSG_SERVICE)) { // Twilio
    const f = new URLSearchParams({ To: to, Body: text });
    if (env.TWILIO_MSG_SERVICE) f.set('MessagingServiceSid', env.TWILIO_MSG_SERVICE); else f.set('From', env.TWILIO_FROM);
    const r = await fetch('https://api.twilio.com/2010-04-01/Accounts/' + env.TWILIO_SID + '/Messages.json', {
      method: 'POST',
      headers: { authorization: 'Basic ' + Buffer.from(env.TWILIO_SID + ':' + env.TWILIO_TOKEN).toString('base64'), 'content-type': 'application/x-www-form-urlencoded' },
      body: f
    });
    if (!r.ok) throw new Error('twilio ' + r.status + ' ' + (await r.text()).slice(0, 200));
    return true;
  }
  return false;
};
const cloudOk = (u, pw) => {
  try {
    const a = Buffer.from(hashPw(String(pw || ''), u.cloud.salt), 'hex'), b = Buffer.from(u.cloud.hash, 'hex');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch (e) { return false; }
};

// ---- TOTP (приложение-аутентификатор: Google Authenticator, Authy и т.п.), RFC 6238 ----
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const b32enc = buf => { let bits = 0, val = 0, out = ''; for (const byte of buf) { val = (val << 8) | byte; bits += 8; while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; } val &= (1 << bits) - 1; } if (bits > 0) out += B32[(val << (5 - bits)) & 31]; return out; };
const b32dec = str => { let bits = 0, val = 0; const out = []; for (const ch of String(str).toUpperCase().replace(/[^A-Z2-7]/g, '')) { val = (val << 5) | B32.indexOf(ch); bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; val &= (1 << bits) - 1; } } return Buffer.from(out); };
const hotp = (key, counter) => { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(counter)); const h = crypto.createHmac('sha1', key).update(b).digest(); const o = h[19] & 15; return String((((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3]) % 1e6).padStart(6, '0'); };
const safeEq = (x, y) => { const p = Buffer.from(String(x)), q = Buffer.from(String(y)); return p.length === q.length && crypto.timingSafeEqual(p, q); };
// возвращает номер 30-секундного шага (>0) при верном коде, иначе 0; last - уже использованный шаг (защита от повторного ввода)
const totpCheck = (secret, code, last = 0) => {
  code = String(code || '').replace(/\D/g, '');
  if (code.length !== 6) return 0;
  const key = b32dec(secret), c = Math.floor(Date.now() / 30000);
  for (let d = -1; d <= 1; d++) if (c + d > last && safeEq(hotp(key, c + d), code)) return c + d;
  return 0;
};
const newBackup = () => Array.from({ length: 8 }, () => crypto.randomBytes(5).toString('hex'));
const NAME_RE = /^[\p{L}\p{N}_.\- ]{2,24}$/u;

export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  const url = new URL(req.url);
  const route = url.pathname.replace(/^\/api/, '').replace(/\/+$/, '') || '/';
  const POST = req.method === 'POST';
  const s = getStore({ name: 'messenger', consistency: 'strong' });
  const get = k => s.get(k, { type: 'json' });
  const put = (k, v) => s.setJSON(k, v);
  const keysOf = async prefix => ((await s.list({ prefix })).blobs || []).map(b => b.key).sort();
  const names = {};
  const nameOf = async k => (names[k] ??= ((await get('u/' + k)) || {}).name || k);
  const fmt = async m => Object.assign({}, m, { from: await nameOf(m.from), to: await nameOf(m.to) });
  const ucache = {}; // кэш пользователей на время одного запроса
  const getU = async k => (ucache[k] ??= (await get('u/' + k)) || {});
  const dnOf = async k => { const u = await getU(k); return u.dn || u.name || k; }; // имя для показа (логин не меняется)
  const contactsOf = async me => {
    const p = 'c/' + me + '/';
    const ks = (await keysOf(p)).map(k => k.slice(p.length));
    return Promise.all(ks.map(async k => ({ name: await nameOf(k), dn: await dnOf(k), ava: (await getU(k)).ava || '' })));
  };

  // ---- push-уведомления (Web Push). Ключи VAPID создаются автоматически и хранятся в Blobs ----
  const wpLoad = async () => (await import('web-push')).default;
  const vapid = async () => {
    let v = await get('cfg/vapid');
    if (!v || !v.publicKey) { const wp = await wpLoad(); v = wp.generateVAPIDKeys(); await put('cfg/vapid', v); }
    return v;
  };
  const pushTo = async (key, payload, ttl = 60) => {
    try {
      const ks = await keysOf('ps/' + key + '/');
      if (!ks.length) return;
      const wp = await wpLoad(), v = await vapid();
      const opts = { TTL: ttl, urgency: 'high', vapidDetails: { subject: url.origin, publicKey: v.publicKey, privateKey: v.privateKey } };
      const data = JSON.stringify(payload);
      await Promise.all(ks.map(async k => {
        const sub = await get(k);
        if (!sub) return;
        try { await wp.sendNotification(sub, data, opts); }
        catch (e) {
          if (e && (e.statusCode === 404 || e.statusCode === 410)) await s.delete(k).catch(() => {});
          else console.error('push', e && e.statusCode, e && e.body);
        }
      }));
    } catch (e) { console.error('push', e); }
  };
  const preview = m => m.type === 'voice' ? '🎤 Голосовое сообщение' : m.type === 'circle' ? '⭕ Кружок' : String(m.text || '').slice(0, 120);

  let body = {};
  if (POST) { try { body = await req.json(); } catch (e) { return J(400, { error: 'Ошибка запроса' }); } }

  try {
    const session = async (key, name) => { const token = crypto.randomBytes(24).toString('hex'); await put('t/' + token, key); return { token, name }; };
    const lockOf = async key => { const l = await get('cl/' + key); return l && l.until && l.until > Date.now() ? l : null; };
    const lockFail = async key => {
      const l = (await get('cl/' + key)) || { fails: 0 };
      l.fails = (l.fails || 0) + 1;
      if (l.fails >= 5) { l.until = Date.now() + 15 * 60e3; l.fails = 0; }
      await put('cl/' + key, l);
    };
    // после проверки пароля/кода: если включена двухэтапная защита приложением - нужен ещё код из приложения
    const finish = async (key, u) => {
      if (u.totp && u.totp.secret) {
        const ticket = crypto.randomBytes(20).toString('hex');
        await put('tk/' + ticket, { key, totp: true, exp: Date.now() + OTP_TTL });
        return J(200, { totp: true, ticket });
      }
      return J(200, await session(key, u.name));
    };

    if (route === '/register' && POST) {
      const name = String(body.name || '').trim(), pw = String(body.password || '');
      if (!NAME_RE.test(name)) return J(400, { error: 'Имя: 2–24 символа, буквы, цифры, пробел, _ . -' });
      if (pw.length < 4) return J(400, { error: 'Пароль: минимум 4 символа' });
      const key = name.toLowerCase();
      if (await get('u/' + key)) return J(409, { error: 'Такое имя уже занято' });
      const salt = crypto.randomBytes(16).toString('hex');
      await put('u/' + key, { name, salt, hash: hashPw(pw, salt) });
      const token = crypto.randomBytes(24).toString('hex');
      await put('t/' + token, key);
      return J(200, { token, name });
    }
    if (route === '/login' && POST) {
      const key = String(body.name || '').trim().toLowerCase();
      const u = key ? await get('u/' + key) : null;
      if (!u || !u.hash || u.hash !== hashPw(String(body.password || ''), u.salt)) { if (u && u.hash) await lockFail(key); return J(401, { error: 'Неверное имя или пароль' }); }
      if (await lockOf(key)) return J(429, { error: 'Слишком много попыток. Подождите 15 минут' });
      return await finish(key, u);
    }

    // ---- вход и регистрация по коду (почта или телефон) ----
    const ident = () => {
      const kind = body.kind === 'phone' ? 'phone' : 'email';
      const val = kind === 'phone' ? normPhone(body.value) : normEmail(body.value);
      return { kind, val, id: kind + ':' + val };
    };

    if (route === '/auth/start' && POST) {
      const { kind, val, id } = ident();
      if (!val) return J(400, { error: kind === 'phone' ? 'Введите номер в формате +79991234567' : 'Введите корректную почту' });
      const now = Date.now(), k = 'otp/' + sha(id);
      const rec = (await get(k)) || { sends: [] };
      rec.sends = (rec.sends || []).filter(t => now - t < 3600e3);
      if (rec.sends.length && now - rec.sends[rec.sends.length - 1] < 45e3) return J(429, { error: 'Подождите минуту перед повторной отправкой' });
      if (rec.sends.length >= 5) return J(429, { error: 'Слишком много попыток. Попробуйте через час' });
      // общий лимит в час: защита от массовой рассылки за ваш счёт
      const gk = 'rl/' + kind + '/' + Math.floor(now / 3600e3), g = (await get(gk)) || { n: 0 };
      if (g.n >= (kind === 'phone' ? 40 : 200)) return J(429, { error: 'Слишком много запросов. Попробуйте позже' });
      const code = String(crypto.randomInt(0, 1e6)).padStart(6, '0'), salt = crypto.randomBytes(8).toString('hex');
      let sent = false;
      try { sent = await sendCode(kind, val, code); }
      catch (e) { console.error('sendCode', e && e.message); return J(502, { error: 'Не удалось отправить код. Проверьте ' + (kind === 'phone' ? 'номер' : 'адрес почты') }); }
      if (!sent) return J(503, { error: 'Отправка кодов не настроена на сервере (переменные окружения Netlify, см. netlify.toml)' });
      g.n++; await put(gk, g);
      rec.sends.push(now);
      Object.assign(rec, { salt, hash: hashCode(code, salt), exp: now + OTP_TTL, tries: 0 });
      await put(k, rec);
      return J(200, { ok: true });
    }

    if (route === '/auth/verify' && POST) {
      const { val, id, kind } = ident();
      const code = String(body.code || '').replace(/\D/g, '');
      const k = 'otp/' + sha(id), rec = val ? await get(k) : null;
      if (!rec || !rec.hash || Date.now() > rec.exp) return J(400, { error: 'Код устарел. Запросите новый' });
      rec.tries = (rec.tries || 0) + 1;
      const a = Buffer.from(hashCode(code, rec.salt)), b = Buffer.from(rec.hash);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
        if (rec.tries >= 5) rec.hash = '';
        await put(k, rec);
        return J(400, { error: rec.hash ? 'Неверный код' : 'Слишком много неверных попыток. Запросите новый код' });
      }
      rec.hash = ''; await put(k, rec); // код одноразовый
      const key = await get('id/' + sha(id));
      const u = key ? await get('u/' + key) : null;
      const ticket = crypto.randomBytes(20).toString('hex');
      if (u) {
        if (u.cloud) { await put('tk/' + ticket, { key, cloud: true, exp: Date.now() + OTP_TTL }); return J(200, { cloud: true, ticket, hint: u.cloud.hint || '' }); }
        return await finish(key, u);
      }
      await put('tk/' + ticket, { kind, val, id, exp: Date.now() + OTP_TTL });
      return J(200, { needName: true, ticket });
    }

    if (route === '/auth/register' && POST) {
      const tkKey = 'tk/' + String(body.ticket || '').replace(/[^a-f0-9]/g, '');
      const tk = await get(tkKey);
      if (!tk || !tk.id || Date.now() > tk.exp) return J(400, { error: 'Сессия устарела. Начните заново' });
      const name = String(body.name || '').trim();
      if (!NAME_RE.test(name)) return J(400, { error: 'Имя: 2–24 символа, буквы, цифры, пробел, _ . -' });
      const key = name.toLowerCase();
      if (await get('u/' + key)) return J(409, { error: 'Такое имя уже занято' });
      if (await get('id/' + sha(tk.id))) return J(409, { error: 'Этот ' + (tk.kind === 'phone' ? 'номер' : 'адрес') + ' уже зарегистрирован. Войдите по коду' });
      await put('u/' + key, { name, [tk.kind]: tk.val, salt: '', hash: '' });
      await put('id/' + sha(tk.id), key);
      await s.delete(tkKey).catch(() => {});
      return J(200, await session(key, name));
    }

    if (route === '/auth/cloud' && POST) {
      const tkKey = 'tk/' + String(body.ticket || '').replace(/[^a-f0-9]/g, '');
      const tk = await get(tkKey);
      if (!tk || !tk.cloud || Date.now() > tk.exp) return J(400, { error: 'Сессия устарела. Начните заново' });
      if (await lockOf(tk.key)) return J(429, { error: 'Слишком много неверных паролей. Подождите 15 минут' });
      const u = await get('u/' + tk.key);
      if (!u || !u.cloud || !cloudOk(u, body.password)) { await lockFail(tk.key); return J(401, { error: 'Неверный облачный пароль' }); }
      await s.delete(tkKey).catch(() => {});
      return await finish(tk.key, u);
    }

    if (route === '/auth/totp' && POST) {
      const tkKey = 'tk/' + String(body.ticket || '').replace(/[^a-f0-9]/g, '');
      const tk = await get(tkKey);
      if (!tk || !tk.totp || Date.now() > tk.exp) return J(400, { error: 'Сессия устарела. Начните заново' });
      if (await lockOf(tk.key)) return J(429, { error: 'Слишком много неверных кодов. Подождите 15 минут' });
      const u = await get('u/' + tk.key);
      if (!u || !u.totp) return J(400, { error: 'Сессия устарела. Начните заново' });
      const raw = String(body.code || '').trim().toLowerCase().replace(/[\s-]/g, '');
      const step = totpCheck(u.totp.secret, raw, u.totp.last || 0);
      let ok = false;
      if (step) { u.totp.last = step; ok = true; }
      else { // резервный код (одноразовый)
        const h = sha('bk:' + raw);
        if (/^[a-f0-9]{10}$/.test(raw) && (u.totp.backup || []).includes(h)) { u.totp.backup = u.totp.backup.filter(x => x !== h); ok = true; }
      }
      if (!ok) { await lockFail(tk.key); return J(401, { error: 'Неверный код' }); }
      await put('u/' + tk.key, u);
      await s.delete(tkKey).catch(() => {});
      return J(200, await session(tk.key, u.name));
    }

    // ---- дальше всё только для вошедших пользователей ----
    const h = req.headers.get('authorization') || '';
    const token = h.startsWith('Bearer ') ? h.slice(7, 107) : '';
    const me = token ? await get('t/' + token) : null;
    if (!me) return J(401, { error: 'Нужен вход' });

    if (route === '/me') {
      const u = (await get('u/' + me)) || {};
      return J(200, { name: await nameOf(me), dn: u.dn || '', ava: u.ava || '', contacts: await contactsOf(me), now: Date.now(), email: u.email || '', phone: u.phone || '', hasCloud: !!u.cloud, hasTotp: !!(u.totp && u.totp.secret), backupLeft: u.totp && u.totp.backup ? u.totp.backup.length : 0, hint: (u.cloud && u.cloud.hint) || '' });
    }

    // ---- профиль: имя для показа и аватарка (логин для входа остаётся прежним) ----
    if (route === '/settings/profile' && POST) {
      const u = await get('u/' + me);
      if (!u) return J(404, { error: 'Аккаунт не найден' });
      if ('dn' in body) {
        const dn = String(body.dn || '').replace(/\s+/g, ' ').trim();
        if (dn.length > 30) return J(400, { error: 'Имя: до 30 символов' });
        if (/[\u0000-\u001f\u007f<>]/.test(dn)) return J(400, { error: 'В имени есть недопустимые символы' });
        if (!dn || dn === u.name) delete u.dn; else u.dn = dn;
      }
      if ('ava' in body) {
        const a = String(body.ava || '');
        if (!a) delete u.ava;
        else {
          if (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(a)) return J(400, { error: 'Нужна картинка' });
          if (a.length > 70000) return J(413, { error: 'Картинка слишком большая' });
          u.ava = a;
        }
      }
      await put('u/' + me, u);
      return J(200, { ok: true, dn: u.dn || '', ava: u.ava || '' });
    }

    // ---- облачный пароль (необязательная двухэтапная проверка при входе по коду) ----
    if ((route === '/settings/cloud' || route === '/settings/cloud/remove') && POST) {
      const u = await get('u/' + me);
      if (!u) return J(404, { error: 'Аккаунт не найден' });
      if (u.cloud) {
        if (await lockOf(me)) return J(429, { error: 'Слишком много неверных паролей. Подождите 15 минут' });
        if (!cloudOk(u, body.current)) { await lockFail(me); return J(401, { error: 'Неверный текущий пароль' }); }
      }
      if (route === '/settings/cloud/remove') { delete u.cloud; await put('u/' + me, u); return J(200, { ok: true }); }
      const pw = String(body.password || ''), hint = String(body.hint || '').trim().slice(0, 60);
      if (pw.length < 6 || pw.length > 100) return J(400, { error: 'Пароль: минимум 6 символов' });
      if (hint && hint.toLowerCase().includes(pw.toLowerCase())) return J(400, { error: 'Подсказка не должна содержать сам пароль' });
      const salt = crypto.randomBytes(16).toString('hex');
      u.cloud = { salt, hash: hashPw(pw, salt), hint };
      await put('u/' + me, u);
      return J(200, { ok: true });
    }

    if (route === '/contacts/add' && POST) {
      const key = String(body.name || '').trim().toLowerCase();
      if (!key || !(await get('u/' + key))) return J(404, { error: 'Такого пользователя нет' });
      if (key === me) return J(400, { error: 'Это вы сами' });
      await put('c/' + me + '/' + key, 1);
      return J(200, { contacts: await contactsOf(me) });
    }

    // ---- двухэтапная защита приложением-аутентификатором ----
    if (route === '/settings/totp/begin' && POST) {
      const u = await get('u/' + me);
      if (!u) return J(404, { error: 'Аккаунт не найден' });
      if (u.totp && u.totp.secret) return J(400, { error: 'Уже включена' });
      const secret = b32enc(crypto.randomBytes(20));
      u.totpPending = { secret, exp: Date.now() + 15 * 60e3 };
      await put('u/' + me, u);
      const label = encodeURIComponent('ARTEM:' + u.name);
      return J(200, { secret, uri: 'otpauth://totp/' + label + '?secret=' + secret + '&issuer=ARTEM&algorithm=SHA1&digits=6&period=30' });
    }
    if (route === '/settings/totp/enable' && POST) {
      const u = await get('u/' + me);
      if (!u || !u.totpPending || Date.now() > u.totpPending.exp) return J(400, { error: 'Начните настройку заново' });
      if (await lockOf(me)) return J(429, { error: 'Слишком много попыток. Подождите 15 минут' });
      const step = totpCheck(u.totpPending.secret, body.code, 0);
      if (!step) { await lockFail(me); return J(400, { error: 'Неверный код. Проверьте время на телефоне и попробуйте ещё раз' }); }
      const backup = newBackup();
      u.totp = { secret: u.totpPending.secret, last: step, backup: backup.map(x => sha('bk:' + x)) };
      delete u.totpPending;
      await put('u/' + me, u);
      return J(200, { ok: true, backup });
    }
    if ((route === '/settings/totp/disable' || route === '/settings/totp/backup') && POST) {
      const u = await get('u/' + me);
      if (!u || !u.totp || !u.totp.secret) return J(400, { error: 'Не включена' });
      if (await lockOf(me)) return J(429, { error: 'Слишком много попыток. Подождите 15 минут' });
      const step = totpCheck(u.totp.secret, body.code, u.totp.last || 0);
      if (!step) { await lockFail(me); return J(401, { error: 'Неверный код' }); }
      if (route === '/settings/totp/disable') { delete u.totp; await put('u/' + me, u); return J(200, { ok: true }); }
      const backup = newBackup();
      u.totp.last = step; u.totp.backup = backup.map(x => sha('bk:' + x));
      await put('u/' + me, u);
      return J(200, { ok: true, backup });
    }

    // ---- истории (живут 24 часа, видны контактам) ----
    if (route === '/stories') {
      const now = Date.now(), cutoff = now - DAY, cp = 'c/' + me + '/';
      const users = [me, ...(await keysOf(cp)).map(k => k.slice(cp.length))];
      const seen = (await get('sv/' + me)) || {};
      const groups = (await Promise.all(users.map(async u => {
        const recs = await Promise.all((await keysOf('st/' + u + '/')).map(async k => [k, await get(k)]));
        const items = [];
        for (const [k, it] of recs) {
          if (!it) continue;
          if (it.ts < cutoff) { s.delete(k).catch(() => {}); if (it.type === 'image') s.delete('sti/' + it.id).catch(() => {}); continue; }
          items.push({ id: it.id, ts: it.ts, type: it.type, text: it.text || '', bg: it.bg || '', cap: it.cap || '', seen: u === me || !!seen[it.id] });
        }
        if (!items.length) return null;
        return { user: await nameOf(u), dn: await dnOf(u), ava: (await getU(u)).ava || '', mine: u === me, items };
      }))).filter(Boolean);
      groups.sort((x, y) => (x.mine ? -1 : 0) - (y.mine ? -1 : 0) || (x.items.every(i => i.seen) ? 1 : 0) - (y.items.every(i => i.seen) ? 1 : 0) || y.items[y.items.length - 1].ts - x.items[x.items.length - 1].ts);
      return J(200, { groups });
    }
    if (route === '/stories/add' && POST) {
      const type = body.type === 'image' ? 'image' : 'text';
      const now = Date.now(), id = crypto.randomBytes(6).toString('hex');
      if ((await keysOf('st/' + me + '/')).length >= 30) return J(400, { error: 'Слишком много активных историй (максимум 30)' });
      const it = { id, ts: now, type, cap: String(body.cap || '').slice(0, 200) };
      if (type === 'image') {
        const img = String(body.image || '');
        if (!/^data:image\/(jpeg|png|webp);base64,/i.test(img.slice(0, 40))) return J(400, { error: 'Нужна картинка' });
        if (img.length > 900000) return J(413, { error: 'Фото слишком большое' });
        await put('sti/' + id, { img, by: me });
      } else {
        it.text = String(body.text || '').trim().slice(0, 300);
        if (!it.text) return J(400, { error: 'Напишите текст' });
        it.bg = /^[0-9a-f]{6}-[0-9a-f]{6}$/i.test(String(body.bg || '')) ? String(body.bg) : '3b9eff-8a3bff';
      }
      await put('st/' + me + '/' + pad(now) + '-' + id, it);
      return J(200, { ok: true, id });
    }
    if (route === '/stories/img') {
      const id = String(url.searchParams.get('id') || '').replace(/[^a-f0-9]/g, '');
      const rec = id ? await get('sti/' + id) : null;
      if (!rec || (rec.by !== me && !(await get('c/' + me + '/' + rec.by)))) return J(404, { error: 'Нет доступа' });
      return J(200, { img: rec.img });
    }
    if (route === '/stories/seen' && POST) {
      const ids = (Array.isArray(body.ids) ? body.ids : []).map(x => String(x).replace(/[^a-f0-9]/g, '')).filter(Boolean).slice(0, 50);
      if (ids.length) {
        const sv = (await get('sv/' + me)) || {}, now = Date.now();
        ids.forEach(i => { sv[i] = now; });
        for (const k of Object.keys(sv)) if (now - sv[k] > 2 * DAY) delete sv[k];
        await put('sv/' + me, sv);
      }
      return J(200, { ok: true });
    }
    if (route === '/stories/delete' && POST) {
      const id = String(body.id || '').replace(/[^a-f0-9]/g, '');
      const k = id && (await keysOf('st/' + me + '/')).find(x => x.endsWith('-' + id));
      if (!k) return J(404, { error: 'Не найдено' });
      await Promise.all([s.delete(k), s.delete('sti/' + id).catch(() => {})]);
      return J(200, { ok: true });
    }

    if (route === '/activity' && POST) {
      const to = String(body.to || '').toLowerCase();
      const action = ['typing', 'recording', 'video'].includes(body.action) ? body.action : '';
      if (!to || to === me) return J(400, { error: 'Пользователь не найден' });
      await put('a/' + me + '/' + to, { action, ts: Date.now() });
      return J(200, { ok: true });
    }

    if (route === '/signal' && POST) { // сигнализация звонков (WebRTC)
      const to = String(body.to || '').toLowerCase();
      const kind = ['offer', 'answer', 'hangup', 'decline', 'busy', 'ice'].includes(body.kind) ? body.kind : '';
      if (!kind || !to || to === me || !(await get('u/' + to))) return J(400, { error: 'Ошибка звонка' });
      if (JSON.stringify(body.data || '').length > 30000) return J(413, { error: 'Слишком большой запрос' });
      const ts = Date.now();
      const cid = String(body.callId || '').slice(0, 40);
      const fromName = await nameOf(me), fromDn = await dnOf(me);
      await Promise.all([ // сигнал и push параллельно - звонок доходит быстрее
        put('s/' + to + '/' + pad(ts) + '-' + crypto.randomBytes(4).toString('hex'), {
          from: fromName, kind, callId: cid, video: !!body.video, data: body.data || null, ts
        }),
        kind === 'offer' ? pushTo(to, { t: 'call', from: fromName, dn: fromDn, video: !!body.video, callId: cid }, 30)
          : kind === 'hangup' && body.missed ? pushTo(to, { t: 'missed', from: fromName, dn: fromDn, callId: cid }, 600) : null
      ]);
      return J(200, { ok: true });
    }

    if (route === '/media') { // видео кружка (только отправитель и получатель)
      const id = String(url.searchParams.get('id') || '').replace(/[^a-f0-9]/g, '');
      const r = id ? await s.getWithMetadata('v/' + id, { type: 'arrayBuffer' }) : null;
      if (!r) return J(404, { error: 'Не найдено' });
      const md = r.metadata || {};
      if (md.from !== me && md.to !== me) return J(403, { error: 'Нет доступа' });
      return new Response(r.data, { status: 200, headers: Object.assign({ 'content-type': md.mime || 'video/mp4', 'cache-control': 'private, max-age=86400' }, CORS) });
    }

    if (route === '/push/key') return J(200, { key: (await vapid()).publicKey });
    if (route === '/push/subscribe' && POST) {
      const sub = body.sub;
      if (!sub || typeof sub.endpoint !== 'string' || !/^https:\/\//.test(sub.endpoint) || !sub.keys || !sub.keys.p256dh || !sub.keys.auth || JSON.stringify(sub).length > 4000)
        return J(400, { error: 'Некорректная подписка' });
      await put('ps/' + me + '/' + sha(sub.endpoint), { endpoint: sub.endpoint, keys: { p256dh: String(sub.keys.p256dh), auth: String(sub.keys.auth) } });
      return J(200, { ok: true });
    }
    if (route === '/push/unsubscribe' && POST) {
      if (body.endpoint) await s.delete('ps/' + me + '/' + sha(body.endpoint)).catch(() => {});
      return J(200, { ok: true });
    }

    if (route === '/messages') {
      const other = String(url.searchParams.get('with') || '').toLowerCase();
      if (!other || !(await get('u/' + other))) return J(404, { error: 'Пользователь не найден' });
      const chat = [me, other].sort().join('|');
      const ks = (await keysOf('m/' + chat + '/')).slice(-60);
      const list = (await Promise.all(ks.map(get))).filter(Boolean);
      return J(200, { messages: await Promise.all(list.map(fmt)) });
    }

    if (route === '/send' && POST) {
      const to = String(body.to || '').toLowerCase();
      if (!to || !(await get('u/' + to))) return J(404, { error: 'Получатель не найден' });
      if (to === me) return J(400, { error: 'Нельзя писать самому себе' });
      const ts = Date.now(), id = crypto.randomBytes(6).toString('hex');
      const m = { id, from: me, to, type: ['voice', 'circle'].includes(body.type) ? body.type : 'text', ts };
      if (m.type === 'circle') { // кружок: видео хранится отдельно, в сообщении только ссылка
        const head = String(body.video || '').slice(0, 120);
        const mm = /^data:(video\/[a-z0-9.+-]+)(?:;[^,;]*)*;base64,/i.exec(head);
        if (!mm) return J(400, { error: 'Нет видео' });
        const b64 = String(body.video).slice(mm[0].length);
        if (b64.length > 5.2e6) return J(413, { error: 'Кружок слишком большой' });
        const buf = Buffer.from(b64, 'base64');
        if (buf.length < 500) return J(400, { error: 'Пустое видео' });
        m.dur = Math.min(120, Number(body.dur) || 0);
        m.mime = mm[1].toLowerCase();
        await s.set('v/' + id, buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), { metadata: { mime: m.mime, from: me, to } });
      } else if (m.type === 'voice') {
        m.audio = String(body.audio || '');
        m.dur = Number(body.dur) || 0;
        if (!m.audio.startsWith('data:audio')) return J(400, { error: 'Нет аудио' });
        if (m.audio.length > 4.5e6) return J(413, { error: 'Голосовое слишком длинное' });
      } else {
        m.text = String(body.text || '').slice(0, 4000);
        if (!m.text.trim()) return J(400, { error: 'Пусто' });
      }
      const chat = [me, to].sort().join('|');
      const mk = 'm/' + chat + '/' + pad(ts) + '-' + id;
      await put(mk, m); // сначала сообщение, потом ссылки на него
      await put('a/' + me + '/' + to, { action: '', ts }); // отправили - «печатает» исчезает
      const ik = pad(ts) + '-' + id, d = day(ts);
      await Promise.all([
        put('i/' + to + '/' + d + '/' + ik, { k: mk }),
        put('i/' + me + '/' + d + '/' + ik, { k: mk }),
        put('c/' + me + '/' + to, 1),
        put('c/' + to + '/' + me, 1),
        (async () => pushTo(to, { t: 'msg', from: await nameOf(me), dn: await dnOf(me), body: preview(m) }, 86400))()
      ]);
      return J(200, { ok: true, message: await fmt(m) });
    }

    if (route === '/poll') {
      const since = Number(url.searchParams.get('since')) || 0;
      const now = Date.now();
      // сигналы звонков (живут 2 минуты)
      const ss = String(url.searchParams.get('ss') || '');
      const sp = 's/' + me + '/';
      const sks = await keysOf(sp);
      const stale = sks.filter(k => now - Number(k.slice(sp.length, sp.length + 15)) > 120000);
      if (stale.length) await Promise.all(stale.map(k => s.delete(k).catch(() => {})));
      const freshKs = sks.filter(k => !stale.includes(k) && k.slice(sp.length) > ss).slice(0, 30);
      const sig = (await Promise.all(freshKs.map(async k => Object.assign({ k: k.slice(sp.length) }, await get(k))))).filter(x => x.kind);
      const cursor = sig.length ? sig[sig.length - 1].k : ss;
      if (url.searchParams.get('sigonly') === '1') return J(200, { messages: [], now, sig, cursor });
      const from = Math.max(since, now - 7 * DAY);
      const days = [];
      for (let t = from; day(t) <= day(now); t += DAY) days.push(day(t));
      const lim = pad(since);
      let refs = [];
      for (const d of days) {
        const p = 'i/' + me + '/' + d + '/';
        const ks = await keysOf(p);
        refs = refs.concat(ks.filter(k => k.slice(p.length, p.length + 15) > lim));
      }
      refs = refs.slice(-100);
      const ptrs = (await Promise.all(refs.map(get))).filter(Boolean);
      const msgs = (await Promise.all(ptrs.map(p => get(p.k)))).filter(Boolean);
      msgs.sort((a, b) => a.ts - b.ts);
      if (url.searchParams.get('hb') === '1') await put('p/' + me, now); // «в сети»
      let peer = null;
      const w = String(url.searchParams.get('with') || '').toLowerCase();
      if (w && w !== me) {
        const [a, last] = await Promise.all([get('a/' + w + '/' + me), get('p/' + w)]);
        const fresh = a && a.action && now - a.ts < 6000;
        peer = { action: fresh ? a.action : '', online: !!last && now - last < 45000, last: last || 0 };
      }
      return J(200, { messages: await Promise.all(msgs.map(fmt)), now, peer, sig, cursor });
    }

    return J(404, { error: 'Не найдено' });
  } catch (e) {
    console.error(e);
    return J(500, { error: 'Ошибка сервера' });
  }
};

export const config = { path: '/api/*' };
