// Адрес сервера (Netlify), с которым работает страница.
// Если страница лежит на GitHub Pages, здесь должен быть адрес вашего сайта на Netlify.
// Если страница лежит на самом Netlify, можно оставить пустую строку ''.
window.ARTEM_SERVER = 'https://benevolent-bienenstitch-7546d7.netlify.app';
