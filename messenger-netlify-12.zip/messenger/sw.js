// Service worker ARTEM: показывает уведомления о звонках и сообщениях, даже когда вкладка закрыта
const ICON = 'icon-192.png';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

self.addEventListener('push', e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (_) {}
  e.waitUntil((async () => {
    const cl = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    // если приложение открыто и в фокусе — оно само покажет звонок/сообщение
    if (cl.some(c => c.visibilityState === 'visible' && c.focused)) return;
    const from = d.from || 'ARTEM';
    const shown = d.dn || from; // имя для показа (логин остаётся в data.from)
    const base = { icon: ICON, badge: ICON, data: { from, call: d.callId || '' } };
    if (d.t === 'call') {
      return self.registration.showNotification('📞 ' + shown, Object.assign({}, base, {
        body: d.video ? 'Входящий видеозвонок' : 'Входящий звонок',
        tag: 'call-' + d.callId, renotify: true, requireInteraction: true,
        vibrate: [500, 250, 500, 250, 500, 250, 500, 250, 500]
      }));
    }
    if (d.t === 'missed') {
      return self.registration.showNotification('Пропущенный звонок', Object.assign({}, base, {
        body: shown, tag: 'call-' + d.callId, vibrate: [200]
      }));
    }
    if (d.t === 'msg') {
      return self.registration.showNotification(shown, Object.assign({}, base, {
        body: d.body || 'Новое сообщение', tag: 'msg-' + from.toLowerCase(), renotify: true, vibrate: [200, 100, 200]
      }));
    }
    return self.registration.showNotification('ARTEM', Object.assign({}, base, { body: 'Новое уведомление' }));
  })());
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const d = e.notification.data || {};
  e.waitUntil((async () => {
    const cl = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of cl) {
      if ('focus' in c) { await c.focus(); c.postMessage({ t: 'open', from: d.from, call: d.call }); return; }
    }
    const base = self.registration.scope;
    await self.clients.openWindow(d.call || !d.from ? base : base + '?from=' + encodeURIComponent(d.from));
  })());
});
