# ARTEM на GitHub Pages

GitHub Pages умеет хранить только страницу (index.html). Сервер мессенджера (вход, сообщения, звонки, истории) остаётся на Netlify.
Поэтому: страница живёт на GitHub Pages, сервер на Netlify, а `config.js` связывает их.

## Шаги
1. Создайте репозиторий на github.com и загрузите в него ВСЕ файлы из архива (включая папки `netlify` и `.github`).
2. В репозитории: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Откройте вкладку **Actions**, дождитесь зелёной галочки у «Deploy to GitHub Pages».
4. Сайт будет по адресу `https://ВАШ-ЛОГИН.github.io/ИМЯ-РЕПОЗИТОРИЯ/`.
5. В `config.js` уже указан адрес сервера на Netlify. Если он другой, замените его на свой.

Сервер Netlify должен быть выложен тоже (он принимает запросы с других адресов, это уже включено).
Netlify лучше подключить к тому же репозиторию (Add new site → Import from GitHub), как описано в `netlify.toml`.
